Version 1.0 (July 2015) 

For more details and future updates please see the pinned tweet at the top of Daniel Donner's twitter account: https://twitter.com/donnermaps. This map is for use with the elections of 2012, 2016, and 2020.

The Electoral College Map by Daniel Donner for Daily Kos Elections is licensed under a Creative Commons Attribution 4.0 International License. 
Please provide a link to https://twitter.com/donnermaps in any published material so that others may take advantage of the files as well.